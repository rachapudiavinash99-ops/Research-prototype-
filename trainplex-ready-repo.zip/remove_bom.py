import os
for f in ["frontend/package.json", "package.json"]:
    try:
        with open(f, 'rb') as file:
            content = file.read()
        if content.startswith(b'\xef\xbb\xbf'):
            with open(f, 'wb') as file:
                file.write(content[3:])
    except:
        pass
