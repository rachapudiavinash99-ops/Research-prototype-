from sqlalchemy.orm import Session
from .models import MaterialsScienceExperiment, MaterialsScienceFinding, MaterialsScienceDataPoint
from .schemas import MaterialsScienceExperimentCreate, MaterialsScienceExperimentUpdate, MaterialsScienceFindingCreate, MaterialsScienceDataPointCreate
from typing import List, Optional

class MaterialsScienceService:
    def __init__(self, db: Session):
        self.db = db

    def get_experiment(self, experiment_id: int) -> Optional[MaterialsScienceExperiment]:
        return self.db.query(MaterialsScienceExperiment).filter(MaterialsScienceExperiment.id == experiment_id).first()

    def get_experiments(self, skip: int = 0, limit: int = 100) -> List[MaterialsScienceExperiment]:
        return self.db.query(MaterialsScienceExperiment).offset(skip).limit(limit).all()

    def create_experiment(self, exp_in: MaterialsScienceExperimentCreate) -> MaterialsScienceExperiment:
        db_exp = MaterialsScienceExperiment(**exp_in.model_dump())
        self.db.add(db_exp)
        self.db.commit()
        self.db.refresh(db_exp)
        return db_exp

    def update_experiment(self, experiment_id: int, exp_in: MaterialsScienceExperimentUpdate) -> Optional[MaterialsScienceExperiment]:
        db_exp = self.get_experiment(experiment_id)
        if not db_exp:
            return None
        update_data = exp_in.model_dump(exclude_unset=True)
        for field, value in update_data.items():
            setattr(db_exp, field, value)
        self.db.add(db_exp)
        self.db.commit()
        self.db.refresh(db_exp)
        return db_exp

    def delete_experiment(self, experiment_id: int) -> bool:
        db_exp = self.get_experiment(experiment_id)
        if not db_exp:
            return False
        self.db.delete(db_exp)
        self.db.commit()
        return True

    def create_finding(self, finding_in: MaterialsScienceFindingCreate) -> MaterialsScienceFinding:
        db_finding = MaterialsScienceFinding(**finding_in.model_dump())
        self.db.add(db_finding)
        self.db.commit()
        self.db.refresh(db_finding)
        return db_finding
        
    def get_findings(self, experiment_id: int) -> List[MaterialsScienceFinding]:
        return self.db.query(MaterialsScienceFinding).filter(MaterialsScienceFinding.experiment_id == experiment_id).all()
        
    def create_datapoint(self, dp_in: MaterialsScienceDataPointCreate) -> MaterialsScienceDataPoint:
        db_dp = MaterialsScienceDataPoint(**dp_in.model_dump())
        self.db.add(db_dp)
        self.db.commit()
        self.db.refresh(db_dp)
        return db_dp
        
    def get_datapoints(self, experiment_id: int) -> List[MaterialsScienceDataPoint]:
        return self.db.query(MaterialsScienceDataPoint).filter(MaterialsScienceDataPoint.experiment_id == experiment_id).all()
