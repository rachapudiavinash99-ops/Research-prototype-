﻿import os

def fix_imports(directory):
    for root, dirs, files in os.walk(directory):
        for file in files:
            if file.endswith('.py'):
                filepath = os.path.join(root, file)
                with open(filepath, 'r', encoding='utf-8') as f:
                    content = f.read()
                
                if 'from app.db.base import Base' in content:
                    content = content.replace('from app.db.base import Base', 'from app.db.session import Base')
                    with open(filepath, 'w', encoding='utf-8') as f:
                        f.write(content)

fix_imports('backend/app/models')
fix_imports('backend/app/domains')
fix_imports('backend/app/db')
