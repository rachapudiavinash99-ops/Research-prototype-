﻿import os

def write_file(path, content):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding='utf-8') as f:
        f.write(content)

app_tsx = '''import { BrowserRouter, Routes, Route, Link } from "react-router-dom";
import { Activity, BookOpen, Layers, LayoutDashboard, Settings } from "lucide-react";
import Dashboard from "./pages/Dashboard";
import Projects from "./pages/Projects";

function Layout({ children }: { children: React.ReactNode }) {
  return (
    <div className="flex h-screen bg-gray-100">
      <aside className="w-64 bg-white shadow-md">
        <div className="p-4 border-b">
          <h1 className="text-xl font-bold text-indigo-600">Prototype Hub</h1>
        </div>
        <nav className="p-4 space-y-2">
          <Link to="/" className="flex items-center space-x-2 p-2 hover:bg-gray-50 rounded-md">
            <LayoutDashboard size={20} />
            <span>Dashboard</span>
          </Link>
          <Link to="/projects" className="flex items-center space-x-2 p-2 hover:bg-gray-50 rounded-md">
            <BookOpen size={20} />
            <span>Projects</span>
          </Link>
          <a href="#" className="flex items-center space-x-2 p-2 hover:bg-gray-50 rounded-md">
            <Layers size={20} />
            <span>Prototypes</span>
          </a>
          <a href="#" className="flex items-center space-x-2 p-2 hover:bg-gray-50 rounded-md">
            <Activity size={20} />
            <span>Experiments</span>
          </a>
          <a href="#" className="flex items-center space-x-2 p-2 hover:bg-gray-50 rounded-md">
            <Settings size={20} />
            <span>Settings</span>
          </a>
        </nav>
      </aside>
      <main className="flex-1 p-8 overflow-y-auto">
        {children}
      </main>
    </div>
  );
}

export default function App() {
  return (
    <BrowserRouter>
      <Layout>
        <Routes>
          <Route path="/" element={<Dashboard />} />
          <Route path="/projects" element={<Projects />} />
        </Routes>
      </Layout>
    </BrowserRouter>
  );
}
'''
write_file("frontend/src/App.tsx", app_tsx)

dashboard_tsx = '''import React from 'react';
export default function Dashboard() {
  return (
    <div>
      <h2 className="text-2xl font-bold mb-6">Research Dashboard</h2>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white p-6 rounded-lg shadow-sm border">
          <h3 className="text-gray-500 text-sm font-medium">Active Projects</h3>
          <p className="text-3xl font-bold mt-2">12</p>
        </div>
        <div className="bg-white p-6 rounded-lg shadow-sm border">
          <h3 className="text-gray-500 text-sm font-medium">Total Prototypes</h3>
          <p className="text-3xl font-bold mt-2">48</p>
        </div>
        <div className="bg-white p-6 rounded-lg shadow-sm border">
          <h3 className="text-gray-500 text-sm font-medium">Experiments Running</h3>
          <p className="text-3xl font-bold mt-2">5</p>
        </div>
      </div>
      <div className="mt-8 bg-white rounded-lg shadow-sm border p-6">
        <h3 className="text-lg font-bold mb-4">Recent Activity</h3>
        <ul className="space-y-4">
          <li className="flex items-center justify-between border-b pb-4">
            <div>
              <p className="font-medium">Alpha Version 2.0 Uploaded</p>
              <p className="text-sm text-gray-500">By Dr. Smith • 2 hours ago</p>
            </div>
            <button className="px-4 py-2 bg-indigo-50 text-indigo-600 rounded-md text-sm font-medium hover:bg-indigo-100 transition-colors">View</button>
          </li>
          <li className="flex items-center justify-between border-b pb-4">
            <div>
              <p className="font-medium">Quantum Simulator Trial Failed</p>
              <p className="text-sm text-gray-500">System • 5 hours ago</p>
            </div>
            <button className="px-4 py-2 bg-indigo-50 text-indigo-600 rounded-md text-sm font-medium hover:bg-indigo-100 transition-colors">View</button>
          </li>
          <li className="flex items-center justify-between">
            <div>
              <p className="font-medium">New Project Created: Gene Therapy</p>
              <p className="text-sm text-gray-500">By Admin • 1 day ago</p>
            </div>
            <button className="px-4 py-2 bg-indigo-50 text-indigo-600 rounded-md text-sm font-medium hover:bg-indigo-100 transition-colors">View</button>
          </li>
        </ul>
      </div>
    </div>
  );
}
'''
write_file("frontend/src/pages/Dashboard.tsx", dashboard_tsx)

projects_tsx = '''import React, { useEffect, useState } from 'react';
import axios from 'axios';

interface Project {
  id: number;
  name: str;
  description: string;
  status: string;
}

export default function Projects() {
  const [projects, setProjects] = useState<Project[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Attempt to fetch real data from backend, fallback to mock data on fail
    axios.get('http://localhost:8001/api/projects')
      .then(res => setProjects(res.data))
      .catch(() => {
        setProjects([
          { id: 1, name: "Quantum Computing Algorithms", description: "Researching Shor's algorithm optimizations", status: "active" },
          { id: 2, name: "Next-Gen NLP Models", description: "Training language models on edge devices", status: "planning" },
          { id: 3, name: "Fusion Reactor Materials", description: "Testing high-heat resistant alloys", status: "experimenting" }
        ]);
      })
      .finally(() => setLoading(false));
  }, []);

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold">Research Projects</h2>
        <button className="bg-indigo-600 text-white px-4 py-2 rounded-md hover:bg-indigo-700 font-medium cursor-pointer" onClick={() => alert("Create Project functionality connected!")}>
          + New Project
        </button>
      </div>
      
      {loading ? (
        <p>Loading projects...</p>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {projects.map(p => (
            <div key={p.id} className="bg-white p-6 rounded-lg shadow-sm border hover:shadow-md transition-shadow">
              <div className="flex justify-between items-start mb-4">
                <h3 className="font-bold text-lg leading-tight">{p.name}</h3>
                <span className={px-2 py-1 text-xs font-medium rounded-full }>
                  {p.status}
                </span>
              </div>
              <p className="text-gray-600 text-sm mb-4 line-clamp-2">{p.description}</p>
              <div className="mt-4 pt-4 border-t flex justify-between items-center">
                <button className="text-indigo-600 text-sm font-medium hover:text-indigo-800 cursor-pointer" onClick={() => alert(Opening project: )}>
                  View Details
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
'''
write_file("frontend/src/pages/Projects.tsx", projects_tsx)

index_css = '''@import "tailwindcss";
body {
  margin: 0;
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', 'Oxygen',
    'Ubuntu', 'Cantarell', 'Fira Sans', 'Droid Sans', 'Helvetica Neue',
    sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}
'''
write_file("frontend/src/index.css", index_css)
