from sqlalchemy.orm import Session
from .models import EcologyExperiment, EcologyFinding, EcologyDataPoint
from .schemas import EcologyExperimentCreate, EcologyExperimentUpdate, EcologyFindingCreate, EcologyDataPointCreate
from typing import List, Optional

class EcologyService:
    def __init__(self, db: Session):
        self.db = db

    def get_experiment(self, experiment_id: int) -> Optional[EcologyExperiment]:
        return self.db.query(EcologyExperiment).filter(EcologyExperiment.id == experiment_id).first()

    def get_experiments(self, skip: int = 0, limit: int = 100) -> List[EcologyExperiment]:
        return self.db.query(EcologyExperiment).offset(skip).limit(limit).all()

    def create_experiment(self, exp_in: EcologyExperimentCreate) -> EcologyExperiment:
        db_exp = EcologyExperiment(**exp_in.model_dump())
        self.db.add(db_exp)
        self.db.commit()
        self.db.refresh(db_exp)
        return db_exp

    def update_experiment(self, experiment_id: int, exp_in: EcologyExperimentUpdate) -> Optional[EcologyExperiment]:
        db_exp = self.get_experiment(experiment_id)
        if not db_exp:
            return None
        update_data = exp_in.model_dump(exclude_unset=True)
        for field, value in update_data.items():
            setattr(db_exp, field, value)
        self.db.add(db_exp)
        self.db.commit()
        self.db.refresh(db_exp)
        return db_exp

    def delete_experiment(self, experiment_id: int) -> bool:
        db_exp = self.get_experiment(experiment_id)
        if not db_exp:
            return False
        self.db.delete(db_exp)
        self.db.commit()
        return True

    def create_finding(self, finding_in: EcologyFindingCreate) -> EcologyFinding:
        db_finding = EcologyFinding(**finding_in.model_dump())
        self.db.add(db_finding)
        self.db.commit()
        self.db.refresh(db_finding)
        return db_finding
        
    def get_findings(self, experiment_id: int) -> List[EcologyFinding]:
        return self.db.query(EcologyFinding).filter(EcologyFinding.experiment_id == experiment_id).all()
        
    def create_datapoint(self, dp_in: EcologyDataPointCreate) -> EcologyDataPoint:
        db_dp = EcologyDataPoint(**dp_in.model_dump())
        self.db.add(db_dp)
        self.db.commit()
        self.db.refresh(db_dp)
        return db_dp
        
    def get_datapoints(self, experiment_id: int) -> List[EcologyDataPoint]:
        return self.db.query(EcologyDataPoint).filter(EcologyDataPoint.experiment_id == experiment_id).all()
