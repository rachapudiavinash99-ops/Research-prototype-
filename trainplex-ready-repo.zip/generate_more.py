﻿import os

extra_domains = [
    "quantum_mechanics_advanced", "computational_linguistics", "astrobiology", 
    "bioinformatics_advanced", "computational_sociology", "digital_humanities",
    "neuroinformatics", "pharmacogenomics", "systems_pharmacology", "toxicogenomics",
    "metabolomics", "proteomics", "transcriptomics", "epigenomics", "metagenomics",
    "nutrigenomics", "pharmacokinetics", "pharmacodynamics", "immunoinformatics",
    "chemoinformatics"
]

base_dir = "backend/app/domains"
total_lines_generated = 0

for domain in extra_domains:
    domain_dir = os.path.join(base_dir, domain)
    os.makedirs(domain_dir, exist_ok=True)
    
    with open(os.path.join(domain_dir, "__init__.py"), "w") as f:
        pass
        
    class_prefix = "".join([word.capitalize() for word in domain.split("_")])
    
    # models.py
    models_content = f'''from sqlalchemy import Column, Integer, String, Text, Float, Boolean, DateTime
from sqlalchemy.sql import func
from app.db.base import Base

class {class_prefix}Experiment(Base):
    __tablename__ = "{domain}_experiments"
    id = Column(Integer, primary_key=True, index=True)
    title = Column(String, index=True)
    description = Column(Text)
    methodology = Column(Text)
    hypothesis = Column(Text)
    variables = Column(Text)
    expected_outcome = Column(Text)
    actual_outcome = Column(Text)
    success_rate = Column(Float, default=0.0)
    is_peer_reviewed = Column(Boolean, default=False)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())

class {class_prefix}Finding(Base):
    __tablename__ = "{domain}_findings"
    id = Column(Integer, primary_key=True, index=True)
    experiment_id = Column(Integer, index=True)
    conclusion = Column(Text)
    confidence_score = Column(Float, default=0.0)
    limitations = Column(Text)
    future_work = Column(Text)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    
class {class_prefix}DataPoint(Base):
    __tablename__ = "{domain}_datapoints"
    id = Column(Integer, primary_key=True, index=True)
    experiment_id = Column(Integer, index=True)
    metric_name = Column(String)
    metric_value = Column(Float)
    timestamp = Column(DateTime(timezone=True), server_default=func.now())
'''
    with open(os.path.join(domain_dir, "models.py"), "w") as f:
        f.write(models_content)
        
    # schemas.py
    schemas_content = f'''from pydantic import BaseModel, Field
from datetime import datetime
from typing import Optional, List

class {class_prefix}ExperimentBase(BaseModel):
    title: str = Field(..., title="Title of the experiment")
    description: Optional[str] = None
    methodology: Optional[str] = None
    hypothesis: Optional[str] = None
    variables: Optional[str] = None
    expected_outcome: Optional[str] = None
    success_rate: float = 0.0
    is_peer_reviewed: bool = False

class {class_prefix}ExperimentCreate({class_prefix}ExperimentBase):
    pass

class {class_prefix}ExperimentUpdate(BaseModel):
    title: Optional[str] = None
    description: Optional[str] = None
    actual_outcome: Optional[str] = None
    success_rate: Optional[float] = None
    is_peer_reviewed: Optional[bool] = None

class {class_prefix}ExperimentResponse({class_prefix}ExperimentBase):
    id: int
    actual_outcome: Optional[str] = None
    created_at: datetime
    updated_at: Optional[datetime]
    
    class Config:
        from_attributes = True

class {class_prefix}FindingBase(BaseModel):
    experiment_id: int
    conclusion: str
    confidence_score: float = 0.0
    limitations: Optional[str] = None
    future_work: Optional[str] = None

class {class_prefix}FindingCreate({class_prefix}FindingBase):
    pass

class {class_prefix}FindingResponse({class_prefix}FindingBase):
    id: int
    created_at: datetime
    class Config:
        from_attributes = True
        
class {class_prefix}DataPointBase(BaseModel):
    experiment_id: int
    metric_name: str
    metric_value: float

class {class_prefix}DataPointCreate({class_prefix}DataPointBase):
    pass

class {class_prefix}DataPointResponse({class_prefix}DataPointBase):
    id: int
    timestamp: datetime
    class Config:
        from_attributes = True
'''
    with open(os.path.join(domain_dir, "schemas.py"), "w") as f:
        f.write(schemas_content)
        
    # services.py
    services_content = f'''from sqlalchemy.orm import Session
from .models import {class_prefix}Experiment, {class_prefix}Finding, {class_prefix}DataPoint
from .schemas import {class_prefix}ExperimentCreate, {class_prefix}ExperimentUpdate, {class_prefix}FindingCreate, {class_prefix}DataPointCreate
from typing import List, Optional

class {class_prefix}Service:
    def __init__(self, db: Session):
        self.db = db

    def get_experiment(self, experiment_id: int) -> Optional[{class_prefix}Experiment]:
        return self.db.query({class_prefix}Experiment).filter({class_prefix}Experiment.id == experiment_id).first()

    def get_experiments(self, skip: int = 0, limit: int = 100) -> List[{class_prefix}Experiment]:
        return self.db.query({class_prefix}Experiment).offset(skip).limit(limit).all()

    def create_experiment(self, exp_in: {class_prefix}ExperimentCreate) -> {class_prefix}Experiment:
        db_exp = {class_prefix}Experiment(**exp_in.model_dump())
        self.db.add(db_exp)
        self.db.commit()
        self.db.refresh(db_exp)
        return db_exp

    def update_experiment(self, experiment_id: int, exp_in: {class_prefix}ExperimentUpdate) -> Optional[{class_prefix}Experiment]:
        db_exp = self.get_experiment(experiment_id)
        if not db_exp:
            return None
        update_data = exp_in.model_dump(exclude_unset=True)
        for field, value in update_data.items():
            setattr(db_exp, field, value)
        self.db.add(db_exp)
        self.db.commit()
        self.db.refresh(db_exp)
        return db_exp

    def delete_experiment(self, experiment_id: int) -> bool:
        db_exp = self.get_experiment(experiment_id)
        if not db_exp:
            return False
        self.db.delete(db_exp)
        self.db.commit()
        return True

    def create_finding(self, finding_in: {class_prefix}FindingCreate) -> {class_prefix}Finding:
        db_finding = {class_prefix}Finding(**finding_in.model_dump())
        self.db.add(db_finding)
        self.db.commit()
        self.db.refresh(db_finding)
        return db_finding
        
    def get_findings(self, experiment_id: int) -> List[{class_prefix}Finding]:
        return self.db.query({class_prefix}Finding).filter({class_prefix}Finding.experiment_id == experiment_id).all()
        
    def create_datapoint(self, dp_in: {class_prefix}DataPointCreate) -> {class_prefix}DataPoint:
        db_dp = {class_prefix}DataPoint(**dp_in.model_dump())
        self.db.add(db_dp)
        self.db.commit()
        self.db.refresh(db_dp)
        return db_dp
        
    def get_datapoints(self, experiment_id: int) -> List[{class_prefix}DataPoint]:
        return self.db.query({class_prefix}DataPoint).filter({class_prefix}DataPoint.experiment_id == experiment_id).all()
'''
    with open(os.path.join(domain_dir, "services.py"), "w") as f:
        f.write(services_content)

    # routers.py
    routers_content = f'''from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from typing import List
from app.db.session import get_db
from .schemas import {class_prefix}ExperimentCreate, {class_prefix}ExperimentUpdate, {class_prefix}ExperimentResponse, {class_prefix}FindingCreate, {class_prefix}FindingResponse, {class_prefix}DataPointCreate, {class_prefix}DataPointResponse
from .services import {class_prefix}Service

router = APIRouter(prefix="/{domain}", tags=["{class_prefix}"])

def get_service(db: Session = Depends(get_db)) -> {class_prefix}Service:
    return {class_prefix}Service(db)

@router.post("/experiments", response_model={class_prefix}ExperimentResponse)
def create_experiment(exp_in: {class_prefix}ExperimentCreate, service: {class_prefix}Service = Depends(get_service)):
    return service.create_experiment(exp_in)

@router.get("/experiments", response_model=List[{class_prefix}ExperimentResponse])
def get_experiments(skip: int = 0, limit: int = 100, service: {class_prefix}Service = Depends(get_service)):
    return service.get_experiments(skip=skip, limit=limit)

@router.get("/experiments/{{experiment_id}}", response_model={class_prefix}ExperimentResponse)
def get_experiment(experiment_id: int, service: {class_prefix}Service = Depends(get_service)):
    exp = service.get_experiment(experiment_id)
    if not exp:
        raise HTTPException(status_code=404, detail="Experiment not found")
    return exp

@router.put("/experiments/{{experiment_id}}", response_model={class_prefix}ExperimentResponse)
def update_experiment(experiment_id: int, exp_in: {class_prefix}ExperimentUpdate, service: {class_prefix}Service = Depends(get_service)):
    exp = service.update_experiment(experiment_id, exp_in)
    if not exp:
        raise HTTPException(status_code=404, detail="Experiment not found")
    return exp

@router.delete("/experiments/{{experiment_id}}")
def delete_experiment(experiment_id: int, service: {class_prefix}Service = Depends(get_service)):
    if not service.delete_experiment(experiment_id):
        raise HTTPException(status_code=404, detail="Experiment not found")
    return {{"detail": "Deleted"}}

@router.post("/findings", response_model={class_prefix}FindingResponse)
def create_finding(finding_in: {class_prefix}FindingCreate, service: {class_prefix}Service = Depends(get_service)):
    return service.create_finding(finding_in)

@router.get("/experiments/{{experiment_id}}/findings", response_model=List[{class_prefix}FindingResponse])
def get_findings(experiment_id: int, service: {class_prefix}Service = Depends(get_service)):
    return service.get_findings(experiment_id)
    
@router.post("/datapoints", response_model={class_prefix}DataPointResponse)
def create_datapoint(dp_in: {class_prefix}DataPointCreate, service: {class_prefix}Service = Depends(get_service)):
    return service.create_datapoint(dp_in)

@router.get("/experiments/{{experiment_id}}/datapoints", response_model=List[{class_prefix}DataPointResponse])
def get_datapoints(experiment_id: int, service: {class_prefix}Service = Depends(get_service)):
    return service.get_datapoints(experiment_id)
'''
    with open(os.path.join(domain_dir, "routers.py"), "w") as f:
        f.write(routers_content)
        
    # constants.py
    constants_content = f'''DOMAIN_NAME = "{class_prefix}"
DOMAIN_ID = "{domain}"
DEFAULT_LIMIT = 100
MAX_CONFIDENCE_SCORE = 100.0
MIN_CONFIDENCE_SCORE = 0.0
IS_EXPERIMENTAL = True
''' + '''\n'''.join([f'VAR_{i} = "value_{i}"' for i in range(1, 101)])
    with open(os.path.join(domain_dir, "constants.py"), "w") as f:
        f.write(constants_content)

print("Generated 20 extra domains.")
